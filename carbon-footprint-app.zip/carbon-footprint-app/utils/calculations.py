def calculate_footprint(transport, electricity, waste):
    """
    Calculate the total carbon footprint based on user inputs.
    Returns the total footprint and a detailed breakdown.
    """
    # Emission factors (kg CO2 per unit)
    transport_emission = transport * 2.3
    electricity_emission = electricity * 1.5
    waste_emission = waste * 0.9

    total = transport_emission + electricity_emission + waste_emission
    breakdown = {
        "Transport": transport_emission,
        "Electricity": electricity_emission,
        "Waste": waste_emission,
    }

    return round(total, 2), breakdown