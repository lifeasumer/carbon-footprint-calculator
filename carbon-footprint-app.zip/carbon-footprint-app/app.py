import os
import json
from flask import Flask, render_template, request, redirect, url_for, session
from werkzeug.utils import secure_filename
from utils.calculations import calculate_footprint
import webbrowser

app = Flask(__name__)
app.secret_key = 'your_secret_key'
app.config['UPLOAD_FOLDER'] = 'static/profile_pictures'
app.config['ALLOWED_EXTENSIONS'] = {'png', 'jpg', 'jpeg', 'gif'}

# Load user data from JSON file
def load_users():
    with open('users.json', 'r') as file:
        return json.load(file)

# Save user data to JSON file
def save_users(users):
    with open('users.json', 'w') as file:
        json.dump(users, file, indent=4)

# Check if the file extension is allowed
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/calculate", methods=["POST"])
def calculate():
    try:
        data = request.form
        transport = float(data.get("transport", 0))
        electricity = float(data.get("electricity", 0))
        waste = float(data.get("waste", 0))

        total, breakdown = calculate_footprint(transport, electricity, waste)

        # Save calculation to user history if logged in
        if session.get("logged_in"):
            username = session.get("username")
            users = load_users()
            user = users["users"].get(username)
            if "history" not in user:
                user["history"] = []
            user["history"].append({
                "transport": transport,
                "electricity": electricity,
                "waste": waste,
                "total": total,
                "breakdown": breakdown
            })
            save_users(users)

        return render_template("index.html", total=total, breakdown=breakdown)
    except ValueError:
        return render_template("index.html", error="Invalid input. Please enter numeric values.")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]

        users = load_users()
        user = users["users"].get(username)
        if user and user["password"] == password:
            session["logged_in"] = True
            session["username"] = username
            session["profile_picture"] = user.get("profile_picture")
            return redirect(url_for("home"))
        else:
            return render_template("login.html", error="Invalid credentials")
    return render_template("login.html")

@app.route("/signup", methods=["GET", "POST"])
def signup():
    if request.method == "POST":
        username = request.form["username"]
        email = request.form["email"]
        password = request.form["password"]
        confirm_password = request.form["confirm_password"]
        verification = request.form.get("verification")

        if password != confirm_password:
            return render_template("signup.html", error="Passwords do not match")
        if not verification:
            return render_template("signup.html", error="Please verify your account")

        users = load_users()
        users["users"][username] = {"email": email, "password": password, "history": []}
        save_users(users)
        session["logged_in"] = True
        session["username"] = username
        return redirect(url_for("home"))
    return render_template("signup.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("home"))

@app.route("/forgot_password", methods=["GET", "POST"])
def forgot_password():
    if request.method == "POST":
        username = request.form["username"]
        email = request.form["email"]
        new_password = request.form["new_password"]
        confirm_new_password = request.form["confirm_new_password"]

        if new_password != confirm_new_password:
            return render_template("forgot_password.html", error="Passwords do not match")

        users = load_users()
        user = users["users"].get(username)
        if user and user["email"] == email:
            user["password"] = new_password
            save_users(users)
            return redirect(url_for("login"))
        else:
            return render_template("forgot_password.html", error="Invalid username or email")
    return render_template("forgot_password.html")

@app.route("/update_password", methods=["GET", "POST"])
def update_password():
    if request.method == "POST":
        old_password = request.form["old_password"]
        new_password = request.form["new_password"]
        confirm_new_password = request.form["confirm_new_password"]

        username = session.get("username")
        users = load_users()
        user = users["users"].get(username)

        if user and user["password"] == old_password:
            if new_password == confirm_new_password:
                user["password"] = new_password
                save_users(users)
                return redirect(url_for("home"))
            else:
                return render_template("update_password.html", error="Passwords do not match")
        else:
            return render_template("update_password.html", error="Invalid old password")
    return render_template("update_password.html")

@app.route("/profile", methods=["GET", "POST"])
def profile():
    username = session.get("username")
    users = load_users()
    user = users["users"].get(username)

    if request.method == "POST":
        new_username = request.form["username"]
        new_email = request.form["email"]

        # Handle profile picture upload
        if 'profile_picture' in request.files:
            file = request.files['profile_picture']
            if file and allowed_file(file.filename):
                filename = secure_filename(file.filename)
                # Ensure the upload folder exists
                if not os.path.exists(app.config['UPLOAD_FOLDER']):
                    os.makedirs(app.config['UPLOAD_FOLDER'])
                file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
                user["profile_picture"] = filename
                session["profile_picture"] = filename

        user["username"] = new_username
        user["email"] = new_email
        users["users"][new_username] = users["users"].pop(username)
        session["username"] = new_username
        save_users(users)
        return redirect(url_for("home"))

    return render_template("profile.html", user=user)

@app.route("/view_history")
def view_history():
    username = session.get("username")
    users = load_users()
    user = users["users"].get(username)
    history = user.get("history", [])
    return render_template("view_history.html", history=history)

if __name__ == "__main__":
    webbrowser.open("http://localhost:5000")
    app.run(host="0.0.0.0", port=5000, debug=True)