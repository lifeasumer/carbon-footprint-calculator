document.addEventListener("DOMContentLoaded", function () {
    const ctx = document.getElementById('footprintChart').getContext('2d');
    if (typeof breakdown !== 'undefined') {
        const data = {
            labels: Object.keys(breakdown),
            datasets: [{
                label: 'Carbon Footprint (kg CO₂)',
                data: Object.values(breakdown),
                backgroundColor: [
                    'rgba(255, 99, 132, 0.2)',
                    'rgba(54, 162, 235, 0.2)',
                    'rgba(75, 192, 192, 0.2)',
                ],
                borderColor: [
                    'rgba(255, 99, 132, 1)',
                    'rgba(54, 162, 235, 1)',
                    'rgba(75, 192, 192, 1)',
                ],
                borderWidth: 1
            }]
        };

        new Chart(ctx, {
            type: 'bar',
            data: data,
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }

    // Toggle left-side menu
    const menuToggle = document.getElementById('menuToggle');
    const sideMenu = document.getElementById('sideMenu');

    menuToggle.addEventListener('click', function() {
        sideMenu.classList.toggle('hidden');
    });
});